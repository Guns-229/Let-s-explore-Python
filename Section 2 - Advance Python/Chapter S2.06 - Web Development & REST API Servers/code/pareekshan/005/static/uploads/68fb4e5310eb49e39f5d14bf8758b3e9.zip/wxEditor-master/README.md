wxEditor
========

A barebones gui text editor written in python, using wxPython. Distributed under GPLv3.
